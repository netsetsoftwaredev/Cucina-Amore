<?php if(!defined('LS_ROOT_FILE')) {  header('HTTP/1.0 403 Forbidden'); exit; } ?>
<script type="text/html" id="tmpl-ls-transition-modal">
	<div id="ls-transition-window" class="ls-modal ls-box">
		<header>
			<h2>Choose a slide transition</h2>
			<div class="filters">
				<span>Show:</span>
				<ul>
					<li class="active">2D</li>
					<li>3D</li>
				</ul>
			</div>
			<b class="dashicons dashicons-no"></b>
		</header>
		<div class="inner">
			<table></table>
		</div>
	</div>
</script>