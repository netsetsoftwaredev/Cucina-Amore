<div class="date-meta">
    <i class="xs-icon glyphicons glyphicons-calendar"></i>
    <time class="published" datetime="<?php echo get_the_time('c'); ?>"><?php echo get_the_date(); ?></time>
    <span class="is-sticky"><?php echo esc_html__('Featured Post', 'stratus'); ?></span>
</div>